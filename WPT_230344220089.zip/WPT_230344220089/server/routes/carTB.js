const express = require('express');
const config = require('config');

const appForCars = express.Router();
const mysql = require('mysql');
var connection = mysql.createConnection({
    host: config.get("host"),
    user: config.get("user"),
    password: config.get("password"),
    database: config.get("database")
});
appForCars.get("/", (request, response) => {
    connection.query("select * from carTB", (error, result) => {
        if (error == null) {
            var data = JSON.stringify(result)
            response.setHeader("Content-Type", "application/json");
            response.write(data);
        }
        else {
            console.log(error);
            response.setHeader("Content-Type", "application/json");
            response.write(error)
        }
        response.end();
    })
})

appForCars.post("/", (request, response) => {
    var query =
        `insert into carTB values(${request.body.id}, '${request.body.name}','${request.body.model}','${request.body.price}','${request.body.carColor}')`;
    connection.query(query, (error, result) => {
        if (error == null) {
            var data = JSON.stringify(result)
            response.setHeader("Content-Type", "application/json");
            response.write(data);
        }
        else {
            console.log(error);
            response.setHeader("Content-Type", "application/json");
            response.write(error)
        }
        response.end();
    })
})
appForCars.put("/:id", (request, response) => {
    var query =
        `update carTB set name = '${request.body.name}',
        model = '${request.body.model}',price = '${request.body.price}',carColor = '${request.body.carColor}' where id = ${request.params.id}`;
    connection.query(query, (error, result) => {
        if (error == null) {
            var data = JSON.stringify(result)
            response.setHeader("Content-Type", "application/json");
            response.write(data);
        }
        else {
            console.log(error);
            response.setHeader("Content-Type", "application/json");
            response.write(error)
        }
        response.end();
    })
})
appForCars.delete("/:id", (request, response) => {
    var query =
        `delete from carTB where id = ${request.params.id}`;
    connection.query(query, (error, result) => {
        if (error == null) {
            var data = JSON.stringify(result)
            response.setHeader("Content-Type", "application/json");
            response.write(data);
        }
        else {
            console.log(error);
            response.setHeader("Content-Type", "application/json");
            response.write(error)
        }
        response.end();
    })
})
module.exports = appForCars;