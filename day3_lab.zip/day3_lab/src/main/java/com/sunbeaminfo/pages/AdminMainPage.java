package com.sunbeaminfo.pages;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.LinkedHashMap;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.sunbeaminfo.dao.CandidateDaoImpl;
import com.sunbeaminfo.pojos.Candidate;
import com.sunbeaminfo.pojos.User;

/**
 * Servlet implementation class AdminMainPage
 */
@WebServlet("/admin_main")
public class AdminMainPage extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		HttpSession hs = request.getSession();
		User user = (User) hs.getAttribute("user_dtls");
		CandidateDaoImpl candidateDao = (CandidateDaoImpl) hs.getAttribute("candidate_dao");
		try (PrintWriter pw = response.getWriter()) {
			// print a greeting to admin
			pw.print("<h4>In admin page </h4>");
			pw.print("Hello , " + user.getFirstName());// null or not null
			List<Candidate> candidate = candidateDao.getTop2Candidates();

			pw.print("<h2> Top Two Candidate : </h2>");
			for (Candidate c : candidate) {
				pw.print("<h5> " + c.getName() + " : " + c.getVotes());
			}

			LinkedHashMap<String, Integer> party = candidateDao.getPartywiseVotes();
			pw.print("<h2> Party			|			Votes</h2>");
			party.forEach((k, v) -> pw.print("<h3>" + k + "			|			" + v + "</h3>"));
//			hs.invalidate();
			pw.print("<h4> <a href='' >List All Candidate</a></h4>");
			pw.print("<h2>Visit Again !!! <br> <a href='login.html'> Logout</a>  <h2>");
		} catch (Exception e) {
			throw new ServletException("in do-get" + getClass(), e);
		}
	}

}
