package com.app.entities;

public enum EmpType {
FULL_TIME,PART_TIME,CONTRACT
}
